import time
import re
from io import BytesIO
from datetime import datetime

import pandas as pd
import requests
import streamlit as st
from bs4 import BeautifulSoup
from urllib.parse import urljoin


# -----------------------------
# CONFIG (same as your script)
# -----------------------------
FORMATS = {
    "Test": 1,
    "ODI": 2,
    "T20I": 3,
    "First-class": 4,
    "List A": 5,
    "T20": 6,
}

VIEWS = {
    "Batting_Innings": "type=batting;view=innings",
    "Bowling_Innings": "type=bowling;view=innings",
    "Fielding_Innings": "type=fielding;view=innings",
    "Batting_Summary": "type=batting",
    "Bowling_Summary": "type=bowling",
    "Fielding_Summary": "type=fielding",
}

BASE_URL = (
    "https://stats.espncricinfo.com/ci/engine/player/{player_id}.html"
    "?class={class_id};template=results;{params}"
)

PROFILE_URL = "https://www.espncricinfo.com/ci/content/player/{player_id}.html"

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/145.0.0.0 Safari/537.36"
    )
}


# -----------------------------
# SCRAPING FUNCTIONS
# -----------------------------
def get_all_pages(start_url, session, max_pages=50, delay=0.6):
    pages = []
    visited = set()
    url = start_url

    for _ in range(max_pages):
        if not url or url in visited:
            break

        visited.add(url)
        resp = session.get(url, headers=HEADERS, timeout=30)
        resp.raise_for_status()

        html = resp.text
        pages.append((url, html))

        soup = BeautifulSoup(html, "html.parser")
        next_link = None

        for a in soup.find_all("a", href=True):
            text = a.get_text(" ", strip=True).lower()
            href = a["href"]
            if "next" in text:
                next_link = urljoin(url, href)
                break

        url = next_link
        time.sleep(delay)

    return pages


def pick_best_table(tables, view_name):
    if not tables:
        return None

    batting_keywords = {"runs", "bf", "4s", "6s", "sr", "mins"}
    bowling_keywords = {"overs", "mdns", "runs", "wkts", "econ", "avg", "sr"}

    best = None
    best_score = -1

    for df in tables:
        cols = {str(c).strip().lower() for c in df.columns}
        if "batting" in view_name.lower():
            score = len(cols & batting_keywords)
        elif "bowling" in view_name.lower():
            score = len(cols & bowling_keywords)
        else:
            # fielding: accept anything reasonable
            score = len(cols)

        score += df.shape[0] * 0.01

        if score > best_score:
            best_score = score
            best = df

    return best if best is not None else tables[0]


def clean_dataframe(df):
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    df = df.dropna(axis=0, how="all")
    df = df.dropna(axis=1, how="all")
    return df.reset_index(drop=True)


def fetch_table_for_url(url, session, view_name):
    pages = get_all_pages(url, session)
    all_parts = []

    for page_url, html in pages:
        try:
            tables = pd.read_html(html)
        except ValueError:
            continue

        df = pick_best_table(tables, view_name)
        if df is None:
            continue

        df = clean_dataframe(df)
        df["source_url"] = page_url
        all_parts.append(df)

    if not all_parts:
        return pd.DataFrame()

    combined = pd.concat(all_parts, ignore_index=True)
    combined = combined.drop_duplicates().reset_index(drop=True)
    return combined


def safe_sheet_name(name: str) -> str:
    for ch in ['\\', '/', '*', '[', ']', ':', '?']:
        name = name.replace(ch, "_")
    return name[:31]


# -----------------------------
# PLAYER PROFILE SCRAPE (for PLAYER_INFO sheet)
# -----------------------------
def scrape_player_profile(player_id: int, session: requests.Session) -> dict:
    """
    Scrapes basic player info from the old ESPN profile page:
    https://www.espncricinfo.com/ci/content/player/{player_id}.html
    """
    url = PROFILE_URL.format(player_id=player_id)
    resp = session.get(url, headers=HEADERS, timeout=30)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    # Name from page header (best-effort)
    name = ""
    h1 = soup.find("h1")
    if h1:
        name = h1.get_text(" ", strip=True)

    # Old profile pages often have:
    # <div class="ciPlayerinformationtxt"><b>Full name</b> ...</div>
    info_map = {}
    for div in soup.find_all("div", class_=re.compile(r"ciPlayerinformationtxt")):
        b = div.find("b")
        if not b:
            continue
        label = b.get_text(" ", strip=True).strip(":").lower()
        value = div.get_text(" ", strip=True)
        # remove the label part from full text
        value = re.sub(r"^\s*" + re.escape(b.get_text(" ", strip=True)) + r"\s*", "", value).strip()
        info_map[label] = value

    # Normalize keys to your desired column names
    out = {
        "Player Name": name,
        "Full Name": info_map.get("full name", ""),
        "Born": info_map.get("born", ""),
        "Age": info_map.get("current age", info_map.get("age", "")),
        "Batting Style": info_map.get("batting style", ""),
        "Bowling Style": info_map.get("bowling style", ""),
        "Playing Role": info_map.get("playing role", ""),
        "Height": info_map.get("height", ""),
        "Education": info_map.get("education", ""),
        "Nicknames": info_map.get("nicknames", ""),
        "Fielding Position": info_map.get("fielding position", ""),
        "Also Known As": info_map.get("also known as", ""),
        "Other": info_map.get("other", ""),
        "Died": info_map.get("died", ""),
    }
    return out


# -----------------------------
# INPUT FILE HELPERS
# -----------------------------
def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    return df


def build_player_info_row_from_file(df_players: pd.DataFrame, player_id: int) -> dict:
    """
    If player exists in uploaded Excel, use those columns.
    Otherwise return empty dict.
    """
    if "player_id" not in df_players.columns:
        return {}

    row = df_players.loc[df_players["player_id"].astype(str) == str(player_id)]
    if row.empty:
        return {}
    row = row.iloc[0].to_dict()

    # Map columns to desired output names
    return {
        "Player Name": row.get("Player Name", ""),
        "Country": row.get("Country", ""),
        "Full Name": row.get("Full Name", ""),
        "Born": row.get("Born", ""),
        "Age": row.get("Age", ""),
        "Batting Style": row.get("Batting Style", ""),
        "Bowling Style": row.get("Bowling Style", ""),
        "Playing Role": row.get("Playing Role", ""),
        "Height": row.get("Height", ""),
        "Education": row.get("Education", ""),
        "Nicknames": row.get("Nicknames", ""),
        "Fielding Position": row.get("Fielding Position", ""),
        "Also Known As": row.get("Also Known As", ""),
        "Other": row.get("Other", ""),
        "Died": row.get("Died", ""),
    }


# -----------------------------
# MAIN GENERATION
# -----------------------------
def generate_excel(player_id: int, match_id: str | None, df_players: pd.DataFrame | None) -> bytes:
    session = requests.Session()
    session.headers.update(HEADERS)

    # Build PLAYER_INFO (file row preferred, else scrape)
    base_info = {}
    if df_players is not None and not df_players.empty:
        base_info = build_player_info_row_from_file(df_players, player_id)

    scraped_info = {}
    if not base_info or all((v == "" or pd.isna(v)) for v in base_info.values()):
        # If not found in file, scrape from ESPN profile (best-effort)
        try:
            scraped_info = scrape_player_profile(player_id, session)
        except Exception:
            scraped_info = {}

    player_info = {}
    player_info.update(scraped_info)
    player_info.update({k: v for k, v in (base_info or {}).items() if str(v).strip() != ""})

    # Ensure these exist
    player_info.setdefault("Player Name", "")
    player_info.setdefault("Country", "")

    # As requested: add "Match ID" column (you can type anything or keep blank)
    player_info_sheet_cols = [
        "Player Name", "Country", "Match ID",
        "Full Name", "Born", "Age",
        "Batting Style", "Bowling Style", "Playing Role",
        "Height", "Education", "Nicknames",
        "Fielding Position", "Also Known As", "Other", "Died"
    ]
    player_info_row = {c: "" for c in player_info_sheet_cols}
    player_info_row.update(player_info)
    player_info_row["Match ID"] = match_id or ""

    player_info_df = pd.DataFrame([player_info_row], columns=player_info_sheet_cols)

    # Now scrape stats and build output Excel in memory
    index_rows = []
    all_data_parts = []

    out_xlsx = BytesIO()
    with pd.ExcelWriter(out_xlsx, engine="openpyxl") as writer:
        # Write player info sheet first
        player_info_df.to_excel(writer, sheet_name="PLAYER_INFO", index=False)

        for format_name, class_id in FORMATS.items():
            for view_name, params in VIEWS.items():
                url = BASE_URL.format(player_id=player_id, class_id=class_id, params=params)
                try:
                    df = fetch_table_for_url(url, session, view_name)

                    if df.empty:
                        index_rows.append({
                            "Format": format_name,
                            "View": view_name,
                            "Rows": 0,
                            "URL": url,
                            "Sheet": ""
                        })
                        continue

                    df.insert(0, "Player ID", player_id)
                    df.insert(1, "Format", format_name)
                    df.insert(2, "View", view_name)

                    sheet_name = safe_sheet_name(f"{format_name}_{view_name}")
                    df.to_excel(writer, sheet_name=sheet_name, index=False)

                    all_data_parts.append(df)

                    index_rows.append({
                        "Format": format_name,
                        "View": view_name,
                        "Rows": len(df),
                        "URL": url,
                        "Sheet": sheet_name
                    })

                except Exception as e:
                    index_rows.append({
                        "Format": format_name,
                        "View": view_name,
                        "Rows": 0,
                        "URL": url,
                        "Sheet": "",
                        "Error": str(e)
                    })

        if all_data_parts:
            all_df = pd.concat(all_data_parts, ignore_index=True)
            all_df.to_excel(writer, sheet_name="ALL_DATA", index=False)

        index_df = pd.DataFrame(index_rows)
        index_df.to_excel(writer, sheet_name="INDEX", index=False)

    return out_xlsx.getvalue()


# -----------------------------
# STREAMLIT UI
# -----------------------------
st.set_page_config(page_title="Cricinfo Player Stats Downloader", layout="wide")
st.title("Cricinfo Player Stats Downloader")

uploaded = st.file_uploader("Upload your Players Excel file (must include: Player Name, Country, player_id)", type=["xlsx", "xls","csv"])

df_players = None
if uploaded:
    df_players = pd.read_csv(uploaded)
    df_players = normalize_columns(df_players)

    if "player_id" not in df_players.columns:
        st.error("Your file must contain a 'player_id' column.")
        st.stop()

    if "Country" not in df_players.columns or "Player Name" not in df_players.columns:
        st.error("Your file must contain 'Country' and 'Player Name' columns.")
        st.stop()

    # Clean
    df_players["Country"] = df_players["Country"].astype(str).str.strip()
    df_players["Player Name"] = df_players["Player Name"].astype(str).str.strip()

col1, col2, col3 = st.columns([1.2, 1.5, 1.2])

with col1:
    match_id = st.text_input("Match ID (optional)", value="")

with col2:
    player_not_found = st.toggle("Player name not found (enable manual Player ID)", value=False)

selected_player_id = None
selected_name = None
selected_country = None

if df_players is not None and not player_not_found:
    countries = sorted([c for c in df_players["Country"].dropna().unique().tolist() if str(c).strip() != ""])
    selected_country = st.selectbox("Select Country", options=countries, index=0 if countries else None)

    filtered = df_players[df_players["Country"] == selected_country].copy()
    filtered = filtered.sort_values("Player Name")

    # Streamlit selectbox is searchable
    selected_name = st.selectbox("Select Player Name (searchable)", options=filtered["Player Name"].tolist())

    # Get ID
    pid_series = filtered.loc[filtered["Player Name"] == selected_name, "player_id"]
    if not pid_series.empty:
        selected_player_id = int(pid_series.iloc[0])

    st.caption(f"Selected Player ID: {selected_player_id}")

if player_not_found:
    with col3:
        selected_player_id = st.number_input("Enter Player ID", min_value=1, step=1, value=253802)

    # Optional manual name/country (only for display in PLAYER_INFO if ESPN scrape fails)
    selected_name_manual = st.text_input("Player Name (optional)", value="")
    selected_country_manual = st.text_input("Country (optional)", value="")

    # If user provided name/country manually, patch df_players-less info later by making a tiny df
    if uploaded is None:
        df_players = pd.DataFrame([{
            "Player Name": selected_name_manual,
            "Country": selected_country_manual,
            "player_id": int(selected_player_id)
        }])

go = st.button("Go", type="primary")

if go:
    if not selected_player_id:
        st.error("Could not determine Player ID. Please select a player or enable manual Player ID.")
        st.stop()

    with st.spinner("Fetching data from Cricinfo..."):
        data = generate_excel(
            player_id=int(selected_player_id),
            match_id=match_id.strip() if match_id else "",
            df_players=df_players
        )

    filename = f"{int(selected_player_id)}.xlsx"
    st.success("Done. Download your Excel file below.")
    st.download_button(
        label="Download Excel",
        data=data,
        file_name=filename,
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )